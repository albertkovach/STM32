AACU - Arduino AnalogClock Updater
Date: 07-Nov-2017


This VS2010 project is a console application.
It will look for COM port in the system and try to communicate with to determine if it is the AnalogClock.

Message sent via COM:
	u2015/7/24 01:57:01u 	--- update time / date
	c			--- expecting replied 'z' for simple identification